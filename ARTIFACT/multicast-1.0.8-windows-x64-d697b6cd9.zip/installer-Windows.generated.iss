#define MyAppName "MultiCast by DKStudio"
#define MyAppVersion "1.0.8"
#define MyAppPublisher "DKStudio"
#define MyAppURL "https://dkstudio.pro"

[Setup]
; NOTE: The value of AppId uniquely identifies this application.
; Do not use the same AppId value in installers for other applications.
; (To generate a new GUID, click Tools | Generate GUID inside the IDE.)
AppId={{7E8814F2-03EE-4E2E-8062-A9A184EC0618}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={code:GetDirName}
AppendDefaultDirName=no
DefaultGroupName={#MyAppName}
OutputBaseFilename={#MyAppName}-{#MyAppVersion}-windows-installer
Compression=lzma
SolidCompression=yes
DirExistsWarning=no
AllowNoIcons=yes
; Wizard Information
WizardStyle=modern
WizardResizable=yes
SetupIconFile="../media/icon.ico"

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "..\release\Package\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\LICENSE"; Flags: dontcopy
; NOTE: Don't use "Flags: ignoreversion" on any shared system files

[Icons]
Name: "{group}\{cm:ProgramOnTheWeb,{#MyAppName}}"; Filename: "{#MyAppURL}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"

[Code]
procedure InitializeWizard();
var
  GPLText: AnsiString;
  Page: TOutputMsgMemoWizardPage;
begin
  ExtractTemporaryFile('LICENSE');
  LoadStringFromFile(ExpandConstant('{tmp}\LICENSE'), GPLText);
  Page := CreateOutputMsgMemoPage(wpWelcome,
    'License Information', 'Please review the license terms before installing {#MyAppName}',
    'Press Page Down to see the rest of the agreement. Once you are aware of your rights, click Next to continue.',
    String(GPLText)
  );
end;

// credit where it's due :
// following function come from https://github.com/Xaymar/obs-studio_amf-encoder-plugin/blob/master/%23Resources/Installer.in.iss#L45
function GetDirName(Value: string): string;
var
  InstallPath: string;
begin
  // initialize default path, which will be returned when the following registry
  // key queries fail due to missing keys or for some different reason
  Result := ExpandConstant('{pf}\obs-studio');
  // query the first registry value; if this succeeds, return the obtained value
  if RegQueryStringValue(HKLM32, 'SOFTWARE\OBS Studio', '', InstallPath) then
    Result := InstallPath;
  if RegQueryStringValue(HKLM64, 'SOFTWARE\OBS Studio', '', InstallPath) then
    Result := InstallPath;
end;

/////////////////////////////////////////////////////////////////////
function NextButtonClick(PageId: Integer): Boolean;
var
    ObsFileName: string;
    ObsMS, ObsLS: Cardinal;
    ObsMajorVersion, ObsMinorVersion: Cardinal;
begin
    Result := True;
    if not (PageId = wpSelectDir) then begin
        exit;
    end;
    ObsFileName := ExpandConstant('{app}\bin\64bit\obs64.exe');
    if not FileExists(ObsFileName) then begin
        MsgBox('OBS Studio (bin\64bit\obs64.exe) does not seem to be installed in that folder.  Please select the correct folder.', mbError, MB_OK);
        Result := False;
        exit;
    end;
    Result := GetVersionNumbers(ObsFileName, ObsMS, ObsLS);
    if not Result then begin
        MsgBox('Failed to read version from OBS Studio (bin\64bit\obs64.exe).', mbError, MB_OK);
        Result := False;
        exit;
    end;
    { shift 16 bits to the right to get major version }
    ObsMajorVersion := ObsMS shr 16; 
    { select only low 16 bits }
    ObsMinorVersion := ObsMS and $FFFF;
    if ObsMajorVersion < 31 then begin
        MsgBox('Version of OBS Studio (bin\64bit\obs64.exe) is lower than the version 31 required.', mbError, MB_OK);
        Result := False;
        exit;
    end;
end;
